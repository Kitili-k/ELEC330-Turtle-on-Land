# ELEC330_TurtleOnLand
# Robotic turtle on Land
# Please include Code, Design files, Bill of materials (components list), Reports (Assignments 1, 2 & 3)
# Please include all other materials (e.g. videos/images)

## To-Do List

1. **Executive Summary**
   - A 2-page executive summary with one figure only (excluding any appendices) in not smaller than 11-point font with no less than 2cm margins.
   - Requirement specifications.
   - Robot design and model.
   - Discussion and reflection on design and model.
   - Contribution of each member of the team clearly and concisely stated.

2. **Detailed Report (Appendices)**
   - Include the detail of all the steps you have gone through to complete the design of the model of the robot.
   - Include a detailed section for each of requirement specification, the design, the model, and how you achieved the model using the CAD files.
   - A reflection section on what worked, what did not work, what lessons were learned, and skills acquired.

3. **Code**
    - URDF
    - Xacro
    - SDF
    - STL

4. **Video**
